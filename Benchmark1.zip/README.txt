The name of the game is : "Richard's Great Adventure"

The firebase URL: [mockups are separate links in the Game Design page]

https://richards-great-adventure.firebaseapp.com/

